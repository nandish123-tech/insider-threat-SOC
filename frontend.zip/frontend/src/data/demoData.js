/* ========== DATA LAYER: synthetic DEMONSTRATION data (not CERT observations). Same schema as the real CSVs. ========== */
export const ACTION={Critical:'Immediate analyst review; propose temporary restriction of removable media and external transfers (simulated)',High:'Priority review within 24h; confirm activity with line manager',Medium:'Add to watch-list; review at next cycle',Low:'No action required; routine monitoring'};
export const POL=['after_hours_logon_violation','after_hours_device_use_violation','usb_device_violation','restricted_file_access_violation','large_file_copy_violation','external_email_violation','large_attachment_email_violation','restricted_http_violation','cloud_upload_http_violation'];
export function buildDemo(){
 let sd=42;const R=()=>{sd|=0;sd=sd+0x6D2B79F5|0;let t=Math.imul(sd^sd>>>15,1|sd);t=t+Math.imul(t^t>>>7,61|t)^t;return((t^t>>>14)>>>0)/4294967296};
 const ri=(a,b)=>a+Math.floor(R()*(b-a)),ru=(a,b)=>a+R()*(b-a),sh=a=>{a=[...a];for(let i=a.length-1;i>0;i--){const j=ri(0,i+1);[a[i],a[j]]=[a[j],a[i]]}return a},pick=(a,k)=>sh(a).slice(0,k),S=a=>new Set(a),N=4000;
 const L='ABCDEFGHIJKLMNOPQRSTUVWXYZ',ids=new Set();while(ids.size<N)ids.add(L[ri(0,26)]+L[ri(0,26)]+L[ri(0,26)]+ri(1000,10000));const id=sh([...ids]);
 const RW=[['Software Engineer',.26],['Customer Support',.16],['Sales Representative',.14],['Finance Analyst',.10],['Operations Manager',.10],['IT Administrator',.08],['HR Specialist',.06],['Executive',.05],['Legal Counsel',.05]];
 const role=id.map(()=>{let u=R(),a=0;for(const[n,w]of RW){a+=w;if(u<a)return n}return RW[0][0]});
 const BASE=[.9,.4,.6,.7,.5,.8,.4,.9,.5],BO={'Sales Representative':{5:2.5,6:2},'IT Administrator':{0:2,1:2.5,2:2.5},'Finance Analyst':{3:2,4:1.5},'Customer Support':{7:1.8},'Software Engineer':{2:1.5,4:1.5,8:1.5},'HR Specialist':{3:1.8},'Executive':{5:1.5}};
 const perm=sh([...Array(N).keys()]),crit=perm.slice(0,16),high=perm.slice(16,133),med=perm.slice(133,220),low=perm.slice(220),level=Array(N).fill('Low');
 crit.forEach(i=>level[i]='Critical');high.forEach(i=>level[i]='High');med.forEach(i=>level[i]='Medium');
 const lowP=pick(low,506),lp=S(lowP),lowN=low.filter(i=>!lp.has(i)),IF=S([...crit,...pick(high,100),...pick([...med,...lowP],34),...pick(lowN,50)]),T=[...crit,...pick(high,19)],P=[...crit,...high,...med,...lowP];
 const score=level.map(l=>l==='Critical'?ru(.86,.99):l==='High'?ru(.62,.86):l==='Medium'?ru(.42,.62):(R()+R()+R())/3*.4*.9);
 const viol=Array.from({length:N},()=>Array(9).fill(0)),KR={Critical:[5,8],High:[3,6],Medium:[2,4],Low:[1,3]};
 P.forEach(i=>{const w=BASE.map((b,j)=>b*((BO[role[i]]||{})[j]||1)),k=ri(...KR[level[i]]);for(let n=0;n<k;n++){const tot=w.reduce((a,b)=>a+b,0);let u=R()*tot,j=0;while(u>=w[j]&&j<8){u-=w[j];j++}viol[i][j]=1;w[j]=0}});
 T.forEach(i=>viol[i][2]=1);
 const res=id.map((u,i)=>{const r={user:u,role:role[i],hybrid_risk_score:score[i].toFixed(4),risk_level:level[i],iforest_anomaly:IF.has(i)?-1:1};POL.forEach((c,j)=>r[c]=viol[i][j]);r.violation_count=viol[i].reduce((a,b)=>a+b,0);r.recommended_action=ACTION[level[i]];return r});
 const p2=n=>String(n).padStart(2,'0'),f=t=>t.getFullYear()+'-'+p2(t.getMonth()+1)+'-'+p2(t.getDate())+' '+p2(t.getHours())+':'+p2(t.getMinutes())+':'+p2(t.getSeconds()),add=(t,m)=>new Date(t.getTime()+m*60000);
 const seqE=[...T,...pick(T,3)],rows=[],ev=[];
 seqE.forEach((i,k)=>{const hs=[19,20,21,22,23,10,14],lg=new Date(2010,2,1+ri(0,400),hs[ri(0,7)],ri(0,60),ri(0,60)),dv=add(lg,ri(3,16)),fc=add(dv,ri(2,11)),tr=add(fc,ri(1,21)),typ=k<22?'Email Send':'Web Upload',pc='PC-'+ri(1000,10000);
  rows.push({user:id[i],pc,login_time:f(lg),device_connect_time:f(dv),file_copy_time:f(fc),transfer_time:f(tr),transfer_type:typ,sequence_duration_min:((tr-lg)/60000).toFixed(1)});
  [['Logon',lg],['Device Connect',dv],['File Copy to Removable Media',fc],[typ,tr]].forEach(([n,t])=>ev.push({user:id[i],pc,event_type:n,timestamp:f(t)}))});
 ev.sort((a,b)=>a.timestamp.localeCompare(b.timestamp));
 return{res:{cols:Object.keys(res[0]),rows:res},tmp:{cols:Object.keys(rows[0]),rows:sh(rows)},evt:{cols:Object.keys(ev[0]),rows:ev}}}
export function demoHistory(emp){const top=emp.filter(x=>x.level==='Critical'||x.level==='High').sort((a,b)=>b.score-a.score).slice(0,7);
 const sp=[['Approve','j.mehta','Removable-media copy followed by external email matches a suspicious pattern; restriction proposed.'],['Approve','a.rao','Repeated after-hours device use; manager could not justify. Approved (simulated).'],['Reject','s.iyer','Manager confirmed approved project work; no restriction needed.'],['Approve','j.mehta','Large web uploads to cloud storage outside business hours.'],['Reject','a.rao','Role requires USB use for field deployments; added to watch-list instead.'],['Approve','s.iyer','Pattern matches earlier Critical case; escalated.'],['Reject','j.mehta','False positive after HR check.']],o={};
 top.forEach((e,i)=>{const[dc,an,nt]=sp[i];o[e.id]={employee_id:e.id,risk_level:e.level,risk_score:e.score.toFixed(4),decision:dc,status:dc==='Approve'?'Restriction Approved (Simulated)':'Restriction Rejected',analyst:an,note:nt,timestamp:new Date(Date.now()-(7-i)*86400000-i*3600000).toLocaleString('sv-SE')}});return o}

