import React,{useState,useEffect,useRef,useMemo} from 'react';
import {html} from './html.js';
import {CONFIG,RC,ORD,PU,PUS,norm,find,truthy,title,fmt,cat,FILES,guess,store,ts,EMPID,T_,cnt,tcols} from './lib/shared.js';
import {MODE_DEFAULT} from './config.js';
import {DataService} from './services/dataService.js';
import {buildDemo} from './data/demoData.js';
import {prepare} from './data/prepare.js';
import {Card,Note,Tag,Plot,Table,Chips} from './components/ui.js';
import {Overview} from './pages/Overview.js';
import {Analytics} from './pages/Analytics.js';
import {Alerts} from './pages/Alerts.js';
import {Temporal} from './pages/Temporal.js';
import {Investigate} from './pages/Investigate.js';
import {Response} from './pages/Response.js';
import {Upload} from './pages/Upload.js';

const PAGES=[['overview','SOC Overview'],['analytics','Detection Analytics'],['alerts','Security Alerts'],['temporal','Temporal Correlation'],['invest','Employee Investigation'],['response','Incident Response']];
export function App(){const demo=useMemo(buildDemo,[]),[mode,setMode]=useState(MODE_DEFAULT),[csv,setCsv]=useState({}),[st,setSt]=useState({}),[gerr,setGerr]=useState(''),[pg,setPg]=useState('overview'),[lv,setLv]=useState(['Critical','High','Medium']),[sel,setSel]=useState(null),[now,setNow]=useState(new Date());
 useEffect(()=>{const t=setInterval(()=>setNow(new Date()),30000);return()=>clearInterval(t)},[]);
 const onFiles=(fs,force)=>{setGerr('');[...fs].forEach(async f=>{const k=force||DataService.guess(f.name);if(!k){setGerr('Unrecognised filename: '+f.name+'. Expected: '+Object.values(DataService.SPEC).map(x=>x.file).join(', '));return}
  const r=await DataService.parse(f,k);setSt(p=>({...p,[k]:r}));if(r.ok)setCsv(p=>({...p,[k]:{cols:r.cols,rows:r.rows}}))})};
 const clear=()=>{setCsv({});setSt({});setGerr('')},chooseMode=m=>{setMode(m);setSel(null);if(m==='csv'&&!csv.res)setPg('data')};
 const raw=mode==='demo'?demo:csv,d=useMemo(()=>{const t=DataService.enrich(raw.tmp);return{...raw,tmp:t,...prepare(raw.res,t,raw.hyb)}},[raw]);
 const ready=!!raw.res&&d.emp.length>0,open=(p,id)=>{if(id)setSel(id);setPg(p)},openEmp=id=>open('invest',id);
 const upload=html`<${Upload} st=${st} csv=${csv} onFiles=${onFiles} clear=${clear} mode=${mode} go=${()=>{setMode('csv');setPg('overview')}}/>`;
 const body=pg==='data'||!ready?upload:pg==='overview'?html`<${Overview} d=${d} go=${open} setLv=${setLv}/>`:pg==='analytics'?html`<${Analytics} d=${d}/>`:pg==='alerts'?html`<${Alerts} d=${d} lv=${lv} setLv=${setLv} open=${openEmp}/>`:pg==='temporal'?html`<${Temporal} d=${d} open=${openEmp}/>`:pg==='invest'?html`<${Investigate} d=${d} sel=${sel} setSel=${setSel}/>`:html`<${Response} key=${mode} d=${d} sel=${sel} setSel=${setSel} mode=${mode}/>`;
 const missing=Object.entries(DataService.SPEC).filter(([k])=>!csv[k]).map(([,s])=>s.file);
 return html`<div class="app"><aside class="side"><div class="logo">🛡️ Insider Threat SOC</div>${PAGES.map(([k,l])=>html`<button key=${k} class=${'nav'+(pg===k?' on':'')} onClick=${()=>setPg(k)}>${l}</button>`)}
 <div class="navsec">Data</div><button class=${'nav'+(pg==='data'?' on':'')} onClick=${()=>setPg('data')}>Data Upload</button>
 <div style=${{margin:'14px 8px 0'}}><div style=${{color:'#6b7280',fontSize:12,marginBottom:6}}>Data mode</div><div class="bar" style=${{gap:6,marginBottom:6}}><button class=${'chip'+(mode==='demo'?' on':'')} onClick=${()=>chooseMode('demo')}>Demo</button><button class=${'chip'+(mode==='csv'?' on':'')} onClick=${()=>chooseMode('csv')}>Actual CERT</button></div>
 ${Object.entries(DataService.SPEC).map(([k,s])=>html`<div key=${k} style=${{fontSize:11,color:csv[k]?'#16a34a':'#9ca3af'}}>${csv[k]?'✓':'○'} ${s.file.replace('.csv','')}</div>`)}</div>
 <div style=${{margin:'18px 8px 0',fontSize:11,color:'#9ca3af'}}>Prototype · no ground-truth labels, so no accuracy metrics are reported.</div></aside>
 <main class="main"><div class="hdr"><div><h1>Insider Threat Detection SOC</h1><p>Role-Aware Security Monitoring and Incident Response</p></div><div style=${{textAlign:'right'}}><span class=${'pill '+(mode==='demo'?'demo':'act')}>${mode==='demo'?'DEMO DATA':'ACTUAL CERT DATA'}</span> <span class="pill">Prototype Active</span><p>${now.toLocaleString([], {dateStyle:'medium',timeStyle:'short'})}</p></div></div>
 ${mode==='demo'?html`<${Note}><b>DEMONSTRATION DATA</b> — every employee, alert and sequence is synthetic and is not CERT observations.<//>`:ready&&pg!=='data'?html`<${Note} warn=${missing.length>0}><b>ACTUAL CERT DATA</b> — ${fmt(d.emp.length)} employees from ${Object.keys(csv).length}/4 files.${missing.length?' Not loaded: '+missing.join(', ')+' (related views will be empty).':''}<//>`:null}
 ${gerr?html`<${Note} warn>${gerr}<//>`:null}${body}</main></div>`}
